
import './App.css';
import Cropper from './components/Cropper';

function App() {
  return (

      <Cropper />
  );
}

export default App;
