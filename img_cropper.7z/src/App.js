
import './App.css';
import Cropper from './components/Cropper';

function App() {
  return (
    <div className="App">
      <h1>teste</h1>
      <Cropper />
    </div>
  );
}

export default App;
