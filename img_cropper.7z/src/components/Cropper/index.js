import React, { useState, useCallback } from 'react'
import Slider from '@material-ui/core/Slider'
import Cropper from 'react-easy-crop'
import './styles.css'

//https://www.youtube.com/watch?v=RmiP1AY5HFM   - assistir este

/// https://www.youtube.com/watch?v=KbPRpBdBN6w&t=750s
/// yarn add react-easy-crop
/// yarn add install @material-ui/core
/// https://www.npmjs.com/package/react-easy-crop
/// :: https://ricardo-ch.github.io/react-easy-crop/
//https://codesandbox.io/s/react-easy-crop-v69ly910ql?from-embed
const Croppie = () => {


    const [src, selectFile] = useState(null);

    const handleFileChange = (e) => {

        selectFile(URL.createObjectURL(e.target.files[0]));
    }

    const [crop, setCrop] = useState({ x: 0, y: 0 })
    const [zoom, setZoom] = useState(1)
    const onCropComplete = useCallback((croppedArea, croppedAreaPixels) => {
        console.log(croppedArea, croppedAreaPixels)
    }, []);

    return(
        <>

        <div className="container">
            <div className="row">
                <div className="col-6">
                    <input type="file" accept="image/*" onChange={handleFileChange} />
                </div>
            </div>
        </div>

        {src && 
            <>
            <div className="crop-container">
                <Cropper
                // image="https://img.huffingtonpost.com/asset/5ab4d4ac2000007d06eb2c56.jpeg?cache=sih0jwle4e&ops=1910_1000"
                image={src}
                crop={crop}
                zoom={zoom}
                aspect={4 / 3}
                onCropChange={setCrop}
                onCropComplete={onCropComplete}
                onZoomChange={setZoom}
                />
            </div>

            <div className="controls">
                <Slider
                value={zoom}
                min={1}
                max={3}
                step={0.1}
                aria-labelledby="Zoom"
                onChange={(e, zoom) => setZoom(zoom)}
                classes={{ root: 'slider' }}
                />
            </div>

            </>
        }

        
        </>
    )
}

export default Croppie;